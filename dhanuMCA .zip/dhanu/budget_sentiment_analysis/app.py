"""
Budget NLP Dashboard  —  Eagle-Eye Admin Panel
Run: streamlit run app.py
"""
from __future__ import annotations
import io, os, pickle, re
from collections import Counter, defaultdict

import matplotlib; matplotlib.use("Agg")
import nltk, numpy as np, pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from nltk.corpus import stopwords
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import sent_tokenize, word_tokenize
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from textblob import TextBlob
from wordcloud import WordCloud

st.set_page_config(
    page_title="Budget NLP | Intelligence Dashboard",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Design Tokens (Eagle-Eye exact) ─────────────────────
GOLD   = "#DAA520"
GOLD_L = "#F4D03F"
GOLD_D = "#B8860B"
GREEN  = "#22C55E"
RED    = "#EF4444"
PURPLE = "#8B5CF6"
BLUE   = "#3B82F6"
AMBER  = "#F59E0B"

PALETTE   = [GOLD, GREEN, RED, PURPLE, BLUE, AMBER, "#F97316", "#EC4899"]
COLORMAPS = ["YlOrBr", "Greens", "Oranges", "Purples", "Reds", "YlOrRd"]

CSS = f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

/* ── Base reset ─────────────────────────────────────── */
html, body, [class*="css"] {{ font-family:'Inter',sans-serif !important; }}

/* Main app background */
.stApp {{ background:#FAFAFA !important; }}
[data-testid="stAppViewContainer"] > section:last-child {{ background:#FAFAFA !important; }}
[data-testid="stMainBlockContainer"] {{
    background:#FAFAFA !important;
    padding:0 1.5rem 2rem !important;
    max-width:1400px !important;
}}

/* ── Scrollbar (golden, eagle-eye exact) ────────────── */
::-webkit-scrollbar {{ width:6px; height:6px; }}
::-webkit-scrollbar-track {{ background:transparent; }}
::-webkit-scrollbar-thumb {{ background:{GOLD}; border-radius:3px; }}
::-webkit-scrollbar-thumb:hover {{ background:{GOLD_D}; }}

/* ── Animations ─────────────────────────────────────── */
@keyframes slideIn  {{ from{{opacity:0;transform:translateY(-8px)}} to{{opacity:1;transform:translateY(0)}} }}
@keyframes countUp  {{ from{{opacity:0;transform:translateY(6px)}}  to{{opacity:1;transform:translateY(0)}} }}
@keyframes pulse-golden {{ 0%,100%{{box-shadow:0 0 0 0 rgba(218,165,32,.4)}} 50%{{box-shadow:0 0 0 8px rgba(218,165,32,0)}} }}
@keyframes ping     {{ 0%{{transform:scale(1);opacity:1}} 75%,100%{{transform:scale(2);opacity:0}} }}

/* ── Sidebar — dark, eagle-eye exact ───────────────── */
section[data-testid="stSidebar"] > div:first-child {{
    background:#1A1A1A !important;
    border-right:1px solid #333 !important;
}}
section[data-testid="stSidebar"] .stMarkdown p,
section[data-testid="stSidebar"] label,
section[data-testid="stSidebar"] span,
section[data-testid="stSidebar"] div {{ color:#A3A3A3 !important; }}
section[data-testid="stSidebar"] h1,
section[data-testid="stSidebar"] h2,
section[data-testid="stSidebar"] h3,
section[data-testid="stSidebar"] strong {{ color:#FFFFFF !important; }}
section[data-testid="stSidebar"] hr {{ border-color:#333 !important; margin:.6rem 0 !important; }}

/* Sidebar multiselect / selectbox */
section[data-testid="stSidebar"] [data-baseweb="select"] > div {{
    background:#292929 !important; border-color:#333 !important;
    color:#FFFFFF !important; border-radius:8px !important;
}}
section[data-testid="stSidebar"] [data-baseweb="select"] span {{ color:#FFFFFF !important; }}
section[data-testid="stSidebar"] .stSlider [data-testid="stSliderThumbValue"] {{ color:{GOLD} !important; }}

/* Sidebar button — golden gradient */
section[data-testid="stSidebar"] .stButton > button {{
    background:linear-gradient(135deg,{GOLD},{GOLD_L}) !important;
    color:#1A1A1A !important; border:none !important;
    border-radius:8px !important; font-weight:700 !important;
    font-size:.82rem !important;
    box-shadow:0 2px 12px rgba(218,165,32,.3) !important;
    transition:all .15s !important;
}}
section[data-testid="stSidebar"] .stButton > button:hover {{
    transform:translateY(-1px) !important;
    box-shadow:0 4px 20px rgba(218,165,32,.5) !important;
    animation:pulse-golden 1.5s ease-in-out;
}}

/* ── Header bar ─────────────────────────────────────── */
.hdr {{
    position:sticky; top:0; z-index:200;
    display:flex; align-items:center; justify-content:space-between;
    height:64px; padding:0 1.5rem;
    background:rgba(250,250,250,.95);
    backdrop-filter:blur(8px);
    border-bottom:1px solid #E5E5E5;
    margin:0 -1.5rem 1.5rem;
}}
.hdr-left {{ display:flex; align-items:center; gap:1rem; }}
.hdr-title {{ font-size:1rem; font-weight:700; color:#1A1A1A; line-height:1.2; }}
.hdr-sub   {{ font-size:.72rem; color:#737373; }}
.hdr-right {{ display:flex; align-items:center; gap:.6rem; }}

/* status pills */
.pill {{
    display:inline-flex; align-items:center; gap:.35rem;
    border-radius:9999px; padding:.25rem .85rem;
    font-size:.72rem; font-weight:600;
}}
.pill-live  {{ background:rgba(34,197,94,.1);  color:#16A34A; }}
.pill-idle  {{ background:#F5F5F5; color:#737373; }}
.pill-red   {{ background:rgba(239,68,68,.1);  color:#DC2626; }}
.dot {{ width:7px; height:7px; border-radius:50%; display:inline-block; }}
.dot-green {{ background:{GREEN}; animation:pulse-golden 2s infinite; }}
.dot-red   {{
    background:{RED}; position:relative; display:inline-block;
}}
.dot-red::after {{
    content:""; position:absolute; inset:0; border-radius:50%;
    background:{RED}; animation:ping 1.2s cubic-bezier(0,0,.2,1) infinite;
    opacity:.75;
}}

/* header action buttons */
.hdr-btn {{
    width:36px; height:36px; border-radius:8px;
    background:#F5F5F5; border:1px solid #E5E5E5;
    display:inline-flex; align-items:center; justify-content:center;
    cursor:pointer; font-size:.9rem; position:relative;
    transition:all .15s;
}}
.hdr-btn:hover {{ background:#FAFAFA; border-color:{GOLD}; }}
.hdr-notif-badge {{
    position:absolute; top:-4px; right:-4px;
    width:15px; height:15px; border-radius:50%;
    background:{RED}; color:white;
    font-size:.55rem; font-weight:800;
    display:flex; align-items:center; justify-content:center;
    border:1.5px solid white;
}}
.hdr-avatar {{
    width:36px; height:36px; border-radius:50%;
    background:linear-gradient(135deg,{GOLD},{GOLD_L});
    display:inline-flex; align-items:center; justify-content:center;
    font-size:.75rem; font-weight:800; color:#1A1A1A;
    border:2px solid transparent; cursor:pointer; transition:.15s;
}}
.hdr-avatar:hover {{ border-color:{GOLD}; }}

/* ── Metric cards — eagle-eye exact ────────────────── */
.mc {{
    background:#FFFFFF;
    border:1px solid #E5E5E5;
    border-radius:10px;
    padding:1rem 1.1rem 1.2rem;
    position:relative; overflow:hidden;
    box-shadow:0 1px 3px rgba(0,0,0,.05), 0 1px 2px rgba(0,0,0,.06);
    transition:box-shadow .2s, transform .2s;
    animation:countUp .4s ease-out;
}}
.mc:hover {{
    box-shadow:0 4px 16px rgba(0,0,0,.1);
    transform:translateY(-2px);
}}
.mc-header {{ display:flex; align-items:flex-start; justify-content:space-between; padding-bottom:.6rem; }}
.mc-label {{ font-size:.75rem; font-weight:500; color:#737373; }}
.mc-icon {{
    width:36px; height:36px; border-radius:8px;
    display:flex; align-items:center; justify-content:center; font-size:1rem;
}}
.mc-value {{ font-size:1.65rem; font-weight:700; letter-spacing:-.025em; line-height:1; }}
.mc-sub   {{ font-size:.72rem; color:#737373; margin-top:.25rem; }}
.mc-trend {{
    display:inline-flex; align-items:center; gap:.2rem;
    font-size:.7rem; font-weight:600; margin-top:.2rem;
}}
/* gradient bottom line — 1px, eagle-eye exact */
.mc-line {{
    position:absolute; bottom:0; left:0; right:0; height:3px; border-radius:0 0 10px 10px;
}}
/* variants */
.mc-gold  .mc-value {{ color:#1A1A1A; }}
.mc-gold  .mc-icon  {{ background:rgba(218,165,32,.1); }}
.mc-gold  .mc-line  {{ background:linear-gradient(90deg,{GOLD},{GOLD_L}); }}
.mc-green .mc-value {{ color:{GREEN}; }}
.mc-green .mc-icon  {{ background:rgba(34,197,94,.1); }}
.mc-green .mc-line  {{ background:linear-gradient(90deg,{GREEN},#4ADE80); }}
.mc-red   .mc-value {{ color:{RED}; }}
.mc-red   .mc-icon  {{ background:rgba(239,68,68,.1); }}
.mc-red   .mc-line  {{ background:linear-gradient(90deg,{RED},#F87171); }}
.mc-purple.mc-value {{ color:{PURPLE}; }}
.mc-purple.mc-icon  {{ background:rgba(139,92,246,.1); }}
.mc-purple.mc-line  {{ background:linear-gradient(90deg,{PURPLE},#A78BFA); }}
.mc-blue  .mc-value {{ color:{BLUE}; }}
.mc-blue  .mc-icon  {{ background:rgba(59,130,246,.1); }}
.mc-blue  .mc-line  {{ background:linear-gradient(90deg,{BLUE},#60A5FA); }}

/* ── Content cards ──────────────────────────────────── */
.card {{
    background:#FFFFFF;
    border:1px solid #E5E5E5;
    border-radius:10px;
    box-shadow:0 1px 3px rgba(0,0,0,.05);
    padding:1.1rem 1.25rem 1.25rem;
    margin-bottom:1rem;
    animation:slideIn .3s ease-out;
}}
.card-hdr {{
    display:flex; align-items:center; gap:.6rem;
    padding-bottom:.8rem; margin-bottom:.8rem;
    border-bottom:1px solid #F5F5F5;
}}
.card-hdr-icon {{ font-size:1rem; color:{GOLD}; flex-shrink:0; }}
.card-hdr-title {{ font-size:.9rem; font-weight:600; color:#1A1A1A; }}
.card-hdr-badge {{
    margin-left:auto; background:#FEF3C7; color:#92400E;
    border-radius:9999px; padding:.1rem .6rem;
    font-size:.65rem; font-weight:600;
}}

/* ── Section headings ───────────────────────────────── */
.sh {{
    display:flex; align-items:center; gap:.6rem;
    margin:1.4rem 0 .85rem;
    padding-bottom:.55rem;
    border-bottom:2px solid #F5F5F5;
}}
.sh-dot {{
    width:10px; height:10px; border-radius:2px;
    background:linear-gradient(135deg,{GOLD},{GOLD_L});
    flex-shrink:0;
}}
.sh-title {{ font-size:.95rem; font-weight:700; color:#1A1A1A; }}
.sh-badge {{
    margin-left:auto; background:#FEF3C7;
    border:1px solid rgba(218,165,32,.3);
    color:{GOLD_D}; border-radius:9999px;
    padding:.1rem .6rem; font-size:.68rem; font-weight:700;
}}

/* ── Page header ────────────────────────────────────── */
.page-hdr {{
    display:flex; align-items:center; gap:.85rem;
    margin-bottom:1.25rem; animation:slideIn .3s;
}}
.page-hdr-icon {{
    width:40px; height:40px; border-radius:10px;
    background:rgba(218,165,32,.1);
    display:flex; align-items:center; justify-content:center; font-size:1.1rem;
    border:1px solid rgba(218,165,32,.2);
}}
.page-hdr-title {{ font-size:1.25rem; font-weight:800; color:#1A1A1A; }}
.page-hdr-sub   {{ font-size:.78rem; color:#737373; }}

/* ── Status / badges ────────────────────────────────── */
.badge {{
    display:inline-flex; align-items:center; border-radius:9999px;
    padding:.18rem .65rem; font-size:.68rem; font-weight:600;
    letter-spacing:.03em; text-transform:uppercase;
}}
.badge-pos    {{ background:rgba(34,197,94,.1);  color:#16A34A; }}
.badge-neg    {{ background:rgba(239,68,68,.1);  color:#DC2626; }}
.badge-neu    {{ background:#F5F5F5;             color:#737373; }}
.badge-gold   {{ background:rgba(218,165,32,.1); color:{GOLD_D}; }}
.badge-purple {{ background:rgba(139,92,246,.1); color:#7C3AED; }}

/* ── Filter chips ────────────────────────────────────── */
.chips {{ display:flex; gap:.4rem; flex-wrap:wrap; margin-bottom:1rem; }}
.chip {{
    background:rgba(218,165,32,.08);
    border:1px solid rgba(218,165,32,.25);
    color:{GOLD_D}; border-radius:9999px;
    padding:.18rem .7rem; font-size:.7rem; font-weight:600;
    animation:slideIn .2s;
}}

/* ── System status rows ─────────────────────────────── */
.sys-row {{
    display:flex; align-items:center; justify-content:space-between;
    padding:.5rem 0; font-size:.82rem; border-bottom:1px solid #F5F5F5;
}}
.sys-row:last-child {{ border-bottom:none; }}
.sys-name {{ color:#1A1A1A; }}
.sys-status {{
    display:flex; align-items:center; gap:.35rem;
    font-size:.72rem; font-weight:600; color:{GREEN};
}}
.sys-dot {{
    width:6px; height:6px; border-radius:50%;
    background:{GREEN}; animation:pulse-golden 2.5s infinite;
}}

/* ── Quick stat rows ────────────────────────────────── */
.stat-row {{
    display:flex; align-items:center; justify-content:space-between;
    padding:.5rem 0; font-size:.82rem; border-bottom:1px solid #F5F5F5;
}}
.stat-row:last-child {{ border-bottom:none; }}
.stat-label {{ color:#737373; }}
.stat-value {{ font-weight:600; color:#1A1A1A; }}

/* ── Progress bar ────────────────────────────────────── */
.prog {{ height:6px; border-radius:3px; background:#F5F5F5; overflow:hidden; margin-top:.3rem; }}
.prog-fill {{ height:100%; border-radius:3px; transition:width .5s ease; }}
.prog-gold   {{ background:linear-gradient(90deg,{GOLD},{GOLD_L}); }}
.prog-green  {{ background:{GREEN}; }}
.prog-red    {{ background:{RED}; }}

/* ── Sentence cards ─────────────────────────────────── */
.sent-card {{
    border-radius:8px; padding:.8rem 1rem; margin-bottom:.55rem;
    font-size:.84rem; line-height:1.6; color:#1A1A1A;
    animation:slideIn .25s;
}}
.sent-pos {{ background:#F0FDF4; border-left:3px solid {GREEN}; }}
.sent-neg {{ background:#FEF2F2; border-left:3px solid {RED};   }}
.score-pill {{
    display:inline-flex; align-items:center;
    border-radius:9999px; padding:.06rem .5rem;
    font-size:.68rem; font-weight:700;
    margin-right:.4rem; vertical-align:middle;
}}
.score-pill-pos {{ background:#DCFCE7; color:#15803D; }}
.score-pill-neg {{ background:#FEE2E2; color:#B91C1C; }}

/* ── Callout boxes ──────────────────────────────────── */
.callout {{
    border-radius:8px; padding:.85rem 1rem; margin-bottom:.7rem;
    display:flex; align-items:center; gap:.75rem;
    animation:slideIn .3s;
}}
.callout-pos {{ background:#F0FDF4; border:1px solid #BBF7D0; }}
.callout-neg {{ background:#FEF2F2; border:1px solid #FECACA; }}
.callout-icon {{ font-size:1.25rem; flex-shrink:0; }}
.callout-body {{ font-size:.84rem; color:#1A1A1A; font-weight:600; }}
.callout-body span {{ font-weight:400; color:#737373; }}

/* ── Upload hint ────────────────────────────────────── */
.upload-hint {{
    background:#FFFFFF; border:2px dashed #E5E5E5;
    border-radius:12px; padding:3rem 2rem;
    text-align:center; color:#737373;
    transition:border-color .2s;
}}
.upload-hint:hover {{ border-color:{GOLD}; }}
.upload-hint h3 {{ color:#1A1A1A; font-size:1.15rem; font-weight:700; margin-bottom:.4rem; }}
.upload-hint p   {{ color:#737373; font-size:.85rem; }}

/* ── Feature card (empty state) ─────────────────────── */
.feat-card {{
    background:#FFFFFF; border:1px solid #E5E5E5;
    border-radius:10px; padding:1rem 1.1rem;
    box-shadow:0 1px 2px rgba(0,0,0,.04);
    animation:countUp .4s ease-out;
    transition:box-shadow .2s, border-color .2s;
}}
.feat-card:hover {{ box-shadow:0 4px 12px rgba(0,0,0,.08); border-color:rgba(218,165,32,.3); }}
.feat-ico {{ font-size:1.25rem; margin-bottom:.5rem; }}
.feat-title {{ font-size:.85rem; font-weight:700; color:#1A1A1A; margin-bottom:.2rem; }}
.feat-desc  {{ font-size:.75rem; color:#737373; line-height:1.4; }}

/* ── Tabs — eagle-eye exact ─────────────────────────── */
.stTabs [data-baseweb="tab-list"] {{
    background:#F5F5F5 !important;
    border-radius:8px !important;
    padding:3px !important;
    gap:2px !important;
    border:none !important;
}}
.stTabs [data-baseweb="tab"] {{
    background:transparent !important;
    color:#737373 !important; border:none !important;
    border-radius:6px !important;
    font-weight:500 !important; font-size:.82rem !important;
    padding:.35rem .9rem !important;
    transition:all .15s !important;
}}
.stTabs [data-baseweb="tab"]:hover {{ color:#1A1A1A !important; }}
.stTabs [aria-selected="true"] {{
    background:{GOLD} !important;
    color:#FFFFFF !important;
    font-weight:700 !important;
}}
.stTabs [data-baseweb="tab-highlight"] {{ display:none !important; }}
.stTabs [data-baseweb="tab-border"]    {{ display:none !important; }}
.stTabs [data-testid="stTabPanel"]     {{ padding-top:1rem !important; }}

/* ── Streamlit widget overrides ─────────────────────── */
hr {{ border-color:#E5E5E5 !important; }}
[data-testid="stDownloadButton"] > button {{
    background:#FFFFFF !important; border:1px solid #E5E5E5 !important;
    color:#1A1A1A !important; border-radius:8px !important; font-size:.8rem !important;
    transition:all .15s !important; box-shadow:0 1px 2px rgba(0,0,0,.05) !important;
}}
[data-testid="stDownloadButton"] > button:hover {{
    border-color:{GOLD} !important; color:{GOLD_D} !important;
}}
[data-testid="stExpander"] {{
    background:#FFFFFF !important; border:1px solid #E5E5E5 !important;
    border-radius:8px !important; box-shadow:none !important;
}}
.stImage img {{ border-radius:8px; border:1px solid #E5E5E5; }}
.stRadio > div {{ gap:.4rem !important; }}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)

# ═══════════════════════════════════════════════
# CONSTANTS
# ═══════════════════════════════════════════════
CUSTOM_STOPWORDS = {
    "crore","lakh","rs","rupees","hon","ble","government","india",
    "budget","speaker","minister","finance","madam","sir","year",
    "also","per","cent","said","one","two","three","shall","would",
    "may","well","will","us","upon","new","i","ii","iii","iv",
    "member","country","scheme","sector","state","national","programme",
    "provide","provided","billion","million","thousand","hundred",
    "announced","announce","proposed","propose","honble",
}
THEMES = {
    "Agriculture":   ["farmer","crop","agricultural","irrigation","rural","kisan","soil","harvest","horticulture","fisheries","livestock","seed"],
    "Infrastructure":["road","railway","airport","port","highway","bridge","urban","metro","logistics","corridor","construction","transit"],
    "Employment":    ["job","employment","skill","workforce","training","apprentice","youth","internship","worker","labour","labor","wage"],
    "Technology":    ["digital","ai","tech","innovation","startup","data","cyber","semiconductor","software","fintech","automation","robot"],
    "Education":     ["school","college","university","education","student","scholarship","curriculum","teacher","research","academic","literacy","learning"],
    "Healthcare":    ["health","hospital","medical","medicine","doctor","pharma","wellness","ayushman","insurance","nutrition","disease","vaccine"],
    "Finance":       ["tax","gst","revenue","fiscal","capital","investment","banking","credit","loan","deficit","bond","equity"],
    "Environment":   ["climate","green","renewable","solar","clean","environment","emission","forest","conservation","carbon","energy","sustainable"],
    "Defense":       ["defence","defense","military","security","army","navy","border","police","weapon","strategic","paramilitary"],
    "Social Welfare":["welfare","poor","poverty","women","tribal","minority","disability","elderly","pension","housing","sanitation","food"],
}
_HERE = os.path.dirname(os.path.abspath(__file__))
DEMO_FILES = {
    "2023-24": os.path.join(_HERE,"..","bs2023_24.txt"),
    "2024-25": os.path.join(_HERE,"..","budget_speech 2024-2025.txt"),
    "2026-27": os.path.join(_HERE,"..","budget_speech.txt"),
}

# ═══════════════════════════════════════════════
# HTML HELPERS
# ═══════════════════════════════════════════════
def mc(label,value,sub,icon,variant="gold"):
    return (f'<div class="mc mc-{variant}">'
            f'<div class="mc-header"><div class="mc-label">{label}</div>'
            f'<div class="mc-icon">{icon}</div></div>'
            f'<div class="mc-value">{value}</div>'
            f'<div class="mc-sub">{sub}</div>'
            f'<div class="mc-line"></div></div>')

def sh(title,badge=None):
    b = f'<span class="sh-badge">{badge}</span>' if badge else ""
    return f'<div class="sh"><div class="sh-dot"></div><span class="sh-title">{title}</span>{b}</div>'

def page_hdr(icon,title,sub):
    return (f'<div class="page-hdr"><div class="page-hdr-icon">{icon}</div>'
            f'<div><div class="page-hdr-title">{title}</div>'
            f'<div class="page-hdr-sub">{sub}</div></div></div>')

def card_wrap(inner,hdr_icon="",hdr_title="",hdr_badge=None):
    hdr = (f'<div class="card-hdr"><span class="card-hdr-icon">{hdr_icon}</span>'
           f'<span class="card-hdr-title">{hdr_title}</span>'
           + (f'<span class="card-hdr-badge">{hdr_badge}</span>' if hdr_badge else "")
           + '</div>') if hdr_title else ""
    return f'<div class="card">{hdr}{inner}</div>'

def header_bar(is_live, n_docs, n_sents, avg_c):
    if is_live:
        badge = (f'<span class="pill pill-live">'
                 f'<span class="dot dot-green"></span>'
                 f'LIVE &nbsp;·&nbsp; {n_docs} docs &nbsp;·&nbsp; {n_sents:,} sentences'
                 f'&nbsp;·&nbsp; avg {avg_c:+.3f}</span>')
    else:
        badge = '<span class="pill pill-idle"><span class="dot" style="background:#D4D4D4"></span>No data loaded</span>'
    return (f'<div class="hdr">'
            f'<div class="hdr-left">'
            f'  <div><div class="hdr-title">🏛️ Budget NLP Intelligence Dashboard</div>'
            f'       <div class="hdr-sub">Sentiment Analysis · TF-IDF · LDA · VADER · TextBlob</div></div>'
            f'  {badge}'
            f'</div>'
            f'<div class="hdr-right">'
            f'  <div class="hdr-btn" title="Notifications">🔔'
            f'    <span class="hdr-notif-badge">!</span></div>'
            f'  <div class="hdr-btn" title="Search">🔍</div>'
            f'  <div class="hdr-avatar">NLP</div>'
            f'</div></div>')

# ═══════════════════════════════════════════════
# PLOTLY THEME
# ═══════════════════════════════════════════════
def sf(fig, h=400, title=""):
    u = dict(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="#FFFFFF",
        font=dict(family="Inter,sans-serif", color="#737373", size=11),
        height=h,
        margin=dict(t=46,b=28,l=10,r=10),
        legend=dict(font=dict(color="#1A1A1A",size=11),
                    bgcolor="rgba(255,255,255,.9)",
                    bordercolor="#E5E5E5", borderwidth=1),
    )
    if title:
        u["title"] = dict(text=title, font=dict(size=13,color="#1A1A1A"))
    fig.update_layout(**u)
    fig.update_xaxes(gridcolor="#F5F5F5", linecolor="#E5E5E5", color="#737373", showgrid=True)
    fig.update_yaxes(gridcolor="#F5F5F5", linecolor="#E5E5E5", color="#737373", showgrid=True)
    return fig

def lc(i): return PALETTE[i % len(PALETTE)]
def hex_rgba(h,a):
    c=h.lstrip("#"); return f"rgba({int(c[:2],16)},{int(c[2:4],16)},{int(c[4:],16)},{a})"

# ═══════════════════════════════════════════════
# NLP PIPELINE
# ═══════════════════════════════════════════════
@st.cache_resource(show_spinner="Loading NLP resources…")
def load_nlp():
    for p in ["punkt","punkt_tab","stopwords","vader_lexicon","wordnet","omw-1.4"]:
        nltk.download(p,quiet=True)
    return WordNetLemmatizer(), SentimentIntensityAnalyzer(), \
           set(stopwords.words("english")) | CUSTOM_STOPWORDS

def clean(t):
    return re.sub(r"\s+"," ",re.sub(r"[^a-z\s]"," ",t.lower())).strip()

def tok(text,lem,sw):
    return [lem.lemmatize(t) for t in word_tokenize(text)
            if t.isalpha() and len(t)>2 and t not in sw]

def ngrams(tokens,n):
    return [" ".join(tokens[i:i+n]) for i in range(len(tokens)-n+1)]

def filtered(d, sr, mw):
    lo,hi=sr; s,c,v,p,sb=[],[],[],[],[]
    for si,ci,vi,pi,sbi in zip(d["sentences"],d["compounds"],d["vader_scores"],
                                d["polarities"],d["subjectivities"]):
        if len(si.split())>=mw and lo<=ci<=hi:
            s.append(si); c.append(ci); v.append(vi); p.append(pi); sb.append(sbi)
    return s,c,v,p,sb

@st.cache_data(show_spinner="Analysing documents…")
def analyse(texts):
    lem,sia,sw = load_nlp()
    res = {}
    for lbl,raw in texts.items():
        toks = tok(clean(raw),lem,sw)
        sents = sent_tokenize(raw)
        vs  = [sia.polarity_scores(s) for s in sents]
        cs  = [s["compound"] for s in vs]
        tb  = [TextBlob(s).sentiment for s in sents]
        pol = [t.polarity for t in tb]
        sub = [t.subjectivity for t in tb]
        tot = len(cs) or 1
        pos = sum(1 for c in cs if c>=.05)
        neg = sum(1 for c in cs if c<=-.05)
        th: dict = defaultdict(list)
        for s,sc in zip(sents,vs):
            sl=s.lower()
            for t2,kws in THEMES.items():
                if any(k in sl for k in kws): th[t2].append(sc["compound"])
        thm = {t2:(round(float(np.mean(v)),4) if v else 0.0) for t2,v in th.items()}
        for t2 in THEMES: thm.setdefault(t2,0.0)
        aw=raw.split(); ut=set(toks)
        res[lbl] = dict(
            tokens=toks, sentences=sents, vader_scores=vs,
            compounds=cs, polarities=pol, subjectivities=sub,
            pos=pos, neg=neg, neu=tot-pos-neg,
            pos_pct=round(pos/tot*100,1), neg_pct=round(neg/tot*100,1),
            neu_pct=round((tot-pos-neg)/tot*100,1),
            mean_compound=round(float(np.mean(cs)),4),
            avg_polarity=round(float(np.mean(pol)),4),
            avg_subjectivity=round(float(np.mean(sub)),4),
            theme_scores=thm,
            stats=dict(total_words=len(aw), unique_tokens=len(ut),
                       sentences=len(sents),
                       vocab_richness=round(len(ut)/len(toks)*100,1) if toks else 0,
                       avg_words_per_sent=round(len(aw)/len(sents),1) if sents else 0),
        )
    labels = list(texts.keys())
    corp = [" ".join(res[l]["tokens"]) for l in labels]
    tv = TfidfVectorizer(max_features=500)
    tm = tv.fit_transform(corp); tf = tv.get_feature_names_out()
    tfd = {}
    for i,l in enumerate(labels):
        row=tm[i].toarray()[0]; top=row.argsort()[-25:][::-1]
        tfd[l]={tf[j]:float(row[j]) for j in top}
    cv2 = CountVectorizer(max_features=1000,min_df=1)
    cm  = cv2.fit_transform(corp)
    return dict(per_doc=res, labels=labels, tfidf_per_doc=tfd,
                lda_store=dict(count_matrix=cm,cv_feat=cv2.get_feature_names_out(),labels=labels))

@st.cache_data(show_spinner=False)
def make_wc(tup,cmap):
    wc = WordCloud(width=700,height=380,background_color="white",
                   colormap=cmap,max_words=150,collocations=False).generate(" ".join(tup))
    buf=io.BytesIO(); wc.to_image().save(buf,"PNG"); return buf.getvalue()

@st.cache_data(show_spinner=False)
def run_lda(cm_bytes,feat_tuple,labels,n_topics,n_top=8):
    cm=pickle.loads(cm_bytes); feat=list(feat_tuple)
    lda=LatentDirichletAllocation(n_components=n_topics,max_iter=100,
                                   learning_method="batch",random_state=42)
    lda.fit(cm)
    words=[[feat[i] for i in t.argsort()[-n_top:][::-1]] for t in lda.components_]
    dist=lda.transform(cm)
    df=pd.DataFrame(dist,index=list(labels),columns=[f"Topic {i+1}" for i in range(n_topics)])
    return words,df

# ═══════════════════════════════════════════════
# TAB 1 — DASHBOARD
# ═══════════════════════════════════════════════
def tab_dashboard(res,labels,sr,mw):
    per=res["per_doc"]
    st.markdown(page_hdr("🏠","Executive Dashboard",
        f"Summary across {len(labels)} document{'s' if len(labels)!=1 else ''}"),
        unsafe_allow_html=True)

    for i,lbl in enumerate(labels):
        d=per[lbl]; clr=lc(i)
        # doc label row
        st.markdown(
            f'<div style="display:flex;align-items:center;gap:.5rem;margin:.9rem 0 .45rem">'
            f'<div style="width:10px;height:10px;border-radius:2px;background:{clr}"></div>'
            f'<span style="font-size:.85rem;font-weight:700;color:#1A1A1A">{lbl}</span>'
            f'</div>', unsafe_allow_html=True)
        c1,c2,c3,c4,c5 = st.columns(5)
        cards=[
            (c1,"Total Words",   f"{d['stats']['total_words']:,}",  f"unique: {d['stats']['unique_tokens']:,}", "📄","gold"),
            (c2,"Sentences",     f"{d['stats']['sentences']:,}",    f"avg {d['stats']['avg_words_per_sent']} words","📝","blue"),
            (c3,"Positive",      f"{d['pos_pct']}%",                f"{d['pos']} sentences",                    "✅","green"),
            (c4,"Negative",      f"{d['neg_pct']}%",                f"{d['neg']} sentences",                    "❌","red"),
            (c5,"VADER Score",   f"{d['mean_compound']:+.4f}",      "mean compound",                             "📊","purple"),
        ]
        for col,lk,val,sub,ico,var in cards:
            col.markdown(mc(lk,val,sub,ico,var), unsafe_allow_html=True)
        st.write("")

    st.markdown("---")
    st.markdown(sh("Sentiment Breakdown"), unsafe_allow_html=True)

    col_a, col_b = st.columns([3,2])
    with col_a:
        df_bar = pd.DataFrame({
            "Document": labels,
            "Positive": [per[l]["pos_pct"] for l in labels],
            "Negative": [per[l]["neg_pct"] for l in labels],
            "Neutral":  [per[l]["neu_pct"]  for l in labels],
        })
        fig=px.bar(df_bar,x="Document",y=["Positive","Negative","Neutral"],
                   barmode="group",color_discrete_sequence=[GREEN,RED,AMBER])
        sf(fig,320,"Sentiment Distribution (%)"); st.plotly_chart(fig,use_container_width=True)

    with col_b:
        if len(labels)>=2:
            best  = max(labels,key=lambda l:per[l]["mean_compound"])
            worst = min(labels,key=lambda l:per[l]["mean_compound"])
            st.markdown(f"""
            <div class="callout callout-pos">
              <span class="callout-icon">🌟</span>
              <div class="callout-body">Most Positive<br>
                <span><strong style="color:#1A1A1A">{best}</strong> &nbsp;·&nbsp; {per[best]['mean_compound']:+.4f}</span>
              </div>
            </div>
            <div class="callout callout-neg">
              <span class="callout-icon">📉</span>
              <div class="callout-body">Least Positive<br>
                <span><strong style="color:#1A1A1A">{worst}</strong> &nbsp;·&nbsp; {per[worst]['mean_compound']:+.4f}</span>
              </div>
            </div>""", unsafe_allow_html=True)

        engines = [("VADER Sentiment","Active"),("TextBlob NLP","Active"),
                   ("TF-IDF Engine","Active"),("LDA Topics","Active")]
        rows="".join(f'<div class="sys-row"><span class="sys-name">{n}</span>'
                     f'<span class="sys-status"><span class="sys-dot"></span>{s}</span></div>'
                     for n,s in engines)
        st.markdown(card_wrap(rows,"⚙️","System Status"), unsafe_allow_html=True)

    if len(labels)>=2:
        st.markdown(sh("Sentiment Trend"), unsafe_allow_html=True)
        tdf=pd.DataFrame({"Document":labels,
                           "VADER":[per[l]["mean_compound"] for l in labels],
                           "TextBlob":[per[l]["avg_polarity"] for l in labels]})
        fig2=px.line(tdf,x="Document",y=["VADER","TextBlob"],
                     markers=True,color_discrete_sequence=[GOLD,BLUE])
        sf(fig2,280,"Mean Sentiment Across Documents"); st.plotly_chart(fig2,use_container_width=True)

    st.markdown("---")
    rows=[{"Label":l,"Words":per[l]["stats"]["total_words"],
           "Sentences":per[l]["stats"]["sentences"],
           "Positive%":per[l]["pos_pct"],"Negative%":per[l]["neg_pct"],
           "VADER":per[l]["mean_compound"],"TextBlob":per[l]["avg_polarity"]}
          for l in labels]
    st.download_button("⬇️ Export Summary CSV",
                       pd.DataFrame(rows).to_csv(index=False).encode(),
                       "nlp_summary.csv","text/csv")

# ═══════════════════════════════════════════════
# TAB 2 — WORD CLOUDS
# ═══════════════════════════════════════════════
def tab_wordclouds(res,labels):
    per=res["per_doc"]
    st.markdown(page_hdr("☁️","Word Clouds","Token frequency visualised per document"),unsafe_allow_html=True)
    n=min(len(labels),3)
    for ri in range((len(labels)+n-1)//n):
        cols=st.columns(n)
        for ci in range(n):
            idx=ri*n+ci
            if idx>=len(labels): break
            lbl=labels[idx]
            cmap=cols[ci].selectbox(f"Colormap — {lbl}",COLORMAPS,
                                    index=idx%len(COLORMAPS),key=f"wc_{lbl}")
            cols[ci].image(make_wc(tuple(per[lbl]["tokens"]),cmap),
                           caption=lbl, use_column_width=True)

# ═══════════════════════════════════════════════
# TAB 3 — SENTIMENT
# ═══════════════════════════════════════════════
def tab_vader(res,labels,sr,mw):
    per=res["per_doc"]
    st.markdown(page_hdr("📊","Sentiment Analysis","VADER compound · TextBlob polarity & subjectivity"),unsafe_allow_html=True)
    mode=st.radio("Chart type",["Pie","Grouped Bar","Gauge"],horizontal=True,key="vm")

    if mode=="Pie":
        cols=st.columns(min(len(labels),3))
        for i,lbl in enumerate(labels):
            d=per[lbl]; _,c,*_=filtered(d,sr,mw); n=len(c) or 1
            pf=sum(1 for x in c if x>=.05); nf=sum(1 for x in c if x<=-.05)
            fig=px.pie(names=["Positive","Negative","Neutral"],
                       values=[pf,nf,n-pf-nf],
                       color_discrete_sequence=[GREEN,RED,AMBER],
                       title=f"{lbl}  ·  {d['mean_compound']:+.4f}")
            sf(fig,300); cols[i%3].plotly_chart(fig,use_container_width=True)
    elif mode=="Grouped Bar":
        rows=[]
        for lbl in labels:
            _,c,*_=filtered(per[lbl],sr,mw); n=len(c) or 1
            pf=sum(1 for x in c if x>=.05); nf=sum(1 for x in c if x<=-.05)
            rows.append({"Document":lbl,"Positive%":round(pf/n*100,1),
                         "Negative%":round(nf/n*100,1),"Neutral%":round((n-pf-nf)/n*100,1)})
        fig=px.bar(pd.DataFrame(rows),x="Document",
                   y=["Positive%","Negative%","Neutral%"],
                   barmode="group",color_discrete_sequence=[GREEN,RED,AMBER])
        sf(fig,380,"Sentiment Distribution"); st.plotly_chart(fig,use_container_width=True)
    else:
        cols=st.columns(min(len(labels),3))
        for i,lbl in enumerate(labels):
            d=per[lbl]
            fig=go.Figure(go.Indicator(
                mode="gauge+number+delta",value=d["mean_compound"],delta={"reference":0},
                gauge={"axis":{"range":[-1,1]},"bar":{"color":lc(i)},
                       "steps":[{"range":[-1,-.05],"color":"rgba(239,68,68,.08)"},
                                 {"range":[-.05,.05],"color":"#F9F9F9"},
                                 {"range":[.05,1],"color":"rgba(34,197,94,.08)"}]},
                title={"text":lbl,"font":{"color":"#1A1A1A","size":12}}))
            fig.update_layout(height=280,paper_bgcolor="rgba(0,0,0,0)",
                              font=dict(color="#737373"))
            cols[i%3].plotly_chart(fig,use_container_width=True)

    st.markdown("---")
    st.markdown(sh("Compound Score Distributions"), unsafe_allow_html=True)
    cols=st.columns(min(len(labels),3))
    for i,lbl in enumerate(labels):
        _,c,*_=filtered(per[lbl],sr,mw)
        if not c: cols[i%3].info("No data for current filters."); continue
        fig=px.histogram(x=c,nbins=30,color_discrete_sequence=[lc(i)],
                         labels={"x":"Compound Score"})
        fig.add_vline(x=float(np.mean(c)),line_dash="dash",line_color=RED,
                      annotation_text=f"Mean {np.mean(c):.3f}",annotation_font_color=RED)
        sf(fig,280,lbl); fig.update_layout(showlegend=False)
        cols[i%3].plotly_chart(fig,use_container_width=True)

    st.markdown("---")
    st.markdown(sh("TextBlob — Polarity vs Subjectivity"), unsafe_allow_html=True)
    cols=st.columns(min(len(labels),3))
    for i,lbl in enumerate(labels):
        _,_,_,pol,sub=filtered(per[lbl],sr,mw)
        if not pol: cols[i%3].info("No data."); continue
        fig=px.scatter(x=pol,y=sub,opacity=.5,color_discrete_sequence=[lc(i)],
                       labels={"x":"Polarity","y":"Subjectivity"})
        fig.add_vline(x=float(np.mean(pol)),line_dash="dash",line_color=RED,
                      annotation_font_color=RED)
        fig.add_hline(y=float(np.mean(sub)),line_dash="dash",line_color=BLUE,
                      annotation_font_color=BLUE)
        sf(fig,280,lbl); cols[i%3].plotly_chart(fig,use_container_width=True)

# ═══════════════════════════════════════════════
# TAB 4 — SENTIMENT GRAPHS
# ═══════════════════════════════════════════════
def tab_sentiment_graphs(res,labels,sr,mw):
    per=res["per_doc"]
    st.markdown(page_hdr("📉","Sentiment Graphs","Violin, heatmap, cumulative trajectory, scatter"),unsafe_allow_html=True)

    # A — Violin+Box
    st.markdown(sh("Violin + Box Distribution"), unsafe_allow_html=True)
    fig=go.Figure()
    for i,lbl in enumerate(labels):
        _,c,*_=filtered(per[lbl],sr,mw)
        if not c: continue
        clr=lc(i)
        fig.add_trace(go.Violin(y=c,name=lbl,box_visible=True,meanline_visible=True,
                                points="outliers",fillcolor=hex_rgba(clr,.2),
                                line_color=clr,opacity=.9))
    sf(fig,440,"Compound Score — Violin + Box"); fig.update_layout(violinmode="overlay")
    st.plotly_chart(fig,use_container_width=True)

    st.markdown("---")

    # B — Heatmap
    st.markdown(sh("Sentiment by Speech Position"), unsafe_allow_html=True)
    nb=20; bd={}
    for lbl in labels:
        _,c,*_=filtered(per[lbl],sr,mw)
        if not c: continue
        n=len(c); bsz=max(1,n//nb)
        bd[lbl]=[float(np.mean(c[b*bsz:b*bsz+bsz if b<nb-1 else n]))
                 for b in range(nb)]
    if bd:
        bdf=pd.DataFrame(bd,index=[f"{int(b*100/nb)}–{int((b+1)*100/nb)}%" for b in range(nb)]).T
        fig2=px.imshow(bdf,color_continuous_scale="RdYlGn",zmin=-.6,zmax=.6,
                       text_auto=".2f",labels=dict(x="Position",y="Doc",color="Compound"))
        sf(fig2,260+40*len(labels),"Speech Position Heatmap")
        st.plotly_chart(fig2,use_container_width=True)

    st.markdown("---")

    # C — Cumulative
    st.markdown(sh("Cumulative Sentiment Trajectory"), unsafe_allow_html=True)
    fig3=go.Figure()
    for i,lbl in enumerate(labels):
        _,c,*_=filtered(per[lbl],sr,mw)
        if not c: continue
        rm=np.cumsum(c)/np.arange(1,len(c)+1); clr=lc(i)
        fig3.add_trace(go.Scatter(x=list(range(len(c))),y=rm.tolist(),name=lbl,
                                  mode="lines",fill="tozeroy",fillcolor=hex_rgba(clr,.08),
                                  line=dict(color=clr,width=2.5)))
    fig3.add_hline(y=0,line_color="#E5E5E5",line_width=1)
    sf(fig3,380,"Running Mean Compound Score")
    fig3.update_layout(xaxis_title="Sentence",yaxis_title="Running Mean")
    st.plotly_chart(fig3,use_container_width=True)

    st.markdown("---")

    # D — Scatter
    st.markdown(sh("Sentence-level Scatter"), unsafe_allow_html=True)
    cols=st.columns(min(len(labels),3))
    for i,lbl in enumerate(labels):
        _,c,*_=filtered(per[lbl],sr,mw)
        if not c: cols[i%3].info("No data."); continue
        n=len(c); pts=[GREEN if x>=.05 else (RED if x<=-.05 else AMBER) for x in c]
        fig4=go.Figure()
        fig4.add_trace(go.Scatter(x=list(range(n)),y=c,mode="markers",
                                  marker=dict(color=pts,size=4,opacity=.6)))
        tr=pd.Series(c).rolling(max(1,n//10),min_periods=1).mean()
        fig4.add_trace(go.Scatter(x=list(range(n)),y=tr.tolist(),mode="lines",
                                  line=dict(color=lc(i),width=2,dash="dash")))
        fig4.add_hline(y=0,line_color="#E5E5E5",line_width=1)
        sf(fig4,280,lbl); fig4.update_layout(showlegend=False)
        cols[i%3].plotly_chart(fig4,use_container_width=True)

# ═══════════════════════════════════════════════
# TAB 5 — TIMELINE
# ═══════════════════════════════════════════════
def tab_timeline(res,labels):
    per=res["per_doc"]
    st.markdown(page_hdr("📈","Sentiment Timeline","Rolling average with positive/negative regions"),unsafe_allow_html=True)
    window=st.slider("Rolling window (sentences)",5,50,20,key="tl_w")
    for i,lbl in enumerate(labels):
        d=per[lbl]; c=d["compounds"]; x=list(range(len(c)))
        roll=pd.Series(c).rolling(window,min_periods=1).mean().tolist()
        mean=float(np.mean(c))
        fig=go.Figure()
        fig.add_trace(go.Scatter(x=x,y=roll,mode="lines",name="Rolling Avg",
                                 line=dict(color=lc(i),width=2.5)))
        fig.add_trace(go.Scatter(x=x,y=[v if v>=0 else 0 for v in roll],fill="tozeroy",
                                 fillcolor=hex_rgba(GREEN,.12),
                                 line=dict(color="rgba(0,0,0,0)"),name="Positive"))
        fig.add_trace(go.Scatter(x=x,y=[v if v<0 else 0 for v in roll],fill="tozeroy",
                                 fillcolor=hex_rgba(RED,.12),
                                 line=dict(color="rgba(0,0,0,0)"),name="Negative"))
        fig.add_hline(y=mean,line_dash="dash",line_color="#737373",
                      annotation_text=f"Mean {mean:.3f}",annotation_font_color="#737373")
        fig.add_hline(y=0,line_color="#E5E5E5",line_width=1)
        sf(fig,360,f"{lbl} — Sentiment Timeline")
        fig.update_layout(xaxis_title="Sentence",yaxis_title="Compound",
                          yaxis=dict(range=[-1.1,1.1]))
        st.plotly_chart(fig,use_container_width=True)

# ═══════════════════════════════════════════════
# TAB 6 — N-GRAMS
# ═══════════════════════════════════════════════
def tab_ngrams(res,labels):
    per=res["per_doc"]
    st.markdown(page_hdr("🔤","N-gram Analysis","Most frequent terms and phrases per document"),unsafe_allow_html=True)
    ng_type=st.radio("Type",["Unigrams","Bigrams","Trigrams"],horizontal=True,key="ng_t")
    n={"Unigrams":1,"Bigrams":2,"Trigrams":3}[ng_type]
    top_n=st.slider("Top N",10,25,15,key="ng_n")
    cols=st.columns(min(len(labels),3))
    for i,lbl in enumerate(labels):
        grams=ngrams(per[lbl]["tokens"],n)
        freq=Counter(grams).most_common(top_n)
        gl=[g for g,_ in reversed(freq)]; gc=[c2 for _,c2 in reversed(freq)]
        fig=px.bar(x=gc,y=gl,orientation="h",color_discrete_sequence=[lc(i)],
                   labels={"x":"Frequency","y":""})
        sf(fig,max(320,top_n*22),f"{lbl} — Top {top_n} {ng_type}")
        fig.update_layout(showlegend=False)
        cols[i%3].plotly_chart(fig,use_container_width=True)

# ═══════════════════════════════════════════════
# TAB 7 — THEMES
# ═══════════════════════════════════════════════
def tab_themes(res,labels,sel_themes):
    per=res["per_doc"]
    themes=sel_themes or list(THEMES.keys())
    st.markdown(page_hdr("🎯","Theme Sentiment","VADER mean score per thematic category"),unsafe_allow_html=True)

    heat=[[per[l]["theme_scores"].get(t,0.0) for l in labels] for t in themes]
    hdf=pd.DataFrame(heat,index=themes,columns=labels)
    fig=px.imshow(hdf,color_continuous_scale="RdYlGn",zmin=-.6,zmax=.6,
                  text_auto=".3f",labels=dict(color="Compound"))
    sf(fig,max(380,len(themes)*36),"Theme-wise Compound Score")
    st.plotly_chart(fig,use_container_width=True)

    if len(labels)>=2:
        st.markdown(sh("Radar — Theme Comparison"), unsafe_allow_html=True)
        fig2=go.Figure()
        for i,lbl in enumerate(labels):
            vals=[per[lbl]["theme_scores"].get(t,0.0) for t in themes]
            fig2.add_trace(go.Scatterpolar(r=vals+[vals[0]],theta=themes+[themes[0]],
                                           fill="toself",name=lbl,line_color=lc(i),
                                           fillcolor=hex_rgba(lc(i),.1),opacity=.9))
        fig2.update_layout(polar=dict(radialaxis=dict(range=[-.6,.6],
                                                       gridcolor="#E5E5E5",
                                                       linecolor="#E5E5E5")),
                           height=480,paper_bgcolor="rgba(0,0,0,0)",
                           font=dict(family="Inter",color="#737373"),
                           title=dict(text="Radar: Theme Sentiment",font=dict(color="#1A1A1A")),
                           legend=dict(bgcolor="white",bordercolor="#E5E5E5",borderwidth=1))
        st.plotly_chart(fig2,use_container_width=True)

# ═══════════════════════════════════════════════
# TAB 8 — TF-IDF
# ═══════════════════════════════════════════════
def tab_tfidf(res,labels,top_n_global):
    st.markdown(page_hdr("🔑","TF-IDF Key Terms","Most distinctive terms per document"),unsafe_allow_html=True)
    top_n=st.slider("Top N terms",10,25,top_n_global,key="tfidf_n")
    tpd=res["tfidf_per_doc"]
    cols=st.columns(min(len(labels),3))
    for i,lbl in enumerate(labels):
        items=sorted(tpd[lbl].items(),key=lambda x:x[1])[-top_n:]
        terms=[t for t,_ in items]; vals=[v for _,v in items]
        fig=px.bar(x=vals,y=terms,orientation="h",color_discrete_sequence=[lc(i)],
                   labels={"x":"TF-IDF","y":""})
        sf(fig,max(320,top_n*22),f"{lbl}"); fig.update_layout(showlegend=False)
        cols[i%3].plotly_chart(fig,use_container_width=True)

# ═══════════════════════════════════════════════
# TAB 9 — TOPICS
# ═══════════════════════════════════════════════
def tab_topics(res,labels,n_topics):
    st.markdown(page_hdr("🗂️","LDA Topic Modeling",f"Latent Dirichlet Allocation — {n_topics} topics"),unsafe_allow_html=True)
    ls=res["lda_store"]
    words,tdf=run_lda(pickle.dumps(ls["count_matrix"]),tuple(ls["cv_feat"]),
                      tuple(ls["labels"]),n_topics)
    for idx,ws in enumerate(words):
        with st.expander(f"Topic {idx+1} — {', '.join(ws[:4])}…"):
            st.write(", ".join(ws))
    st.markdown("---")
    fig=px.imshow(tdf,color_continuous_scale="YlOrRd",text_auto=".3f",
                  labels=dict(color="Weight"))
    sf(fig,320,"Topic Distribution Heatmap"); st.plotly_chart(fig,use_container_width=True)
    fig2=px.bar(tdf.reset_index().rename(columns={"index":"Document"}),
                x="Document",y=tdf.columns.tolist(),barmode="stack",
                color_discrete_sequence=px.colors.qualitative.Set2)
    sf(fig2,360,"Topic Distribution (Stacked)")
    fig2.update_layout(xaxis_title="Document",yaxis_title="Weight")
    st.plotly_chart(fig2,use_container_width=True)

# ═══════════════════════════════════════════════
# TAB 10 — KEY SENTENCES
# ═══════════════════════════════════════════════
def tab_key_sentences(res,labels,sr,mw):
    per=res["per_doc"]
    st.markdown(page_hdr("💬","Key Sentences","Most positive and negative sentences per document"),unsafe_allow_html=True)
    n=st.slider("Sentences per category",3,10,5,key="ks_n")
    for lbl in labels:
        d=per[lbl]; sents,cs,*_=filtered(d,sr,mw)
        st.markdown(sh(lbl,f"{len(sents)} sentences"), unsafe_allow_html=True)
        if not sents: st.info("No sentences match current filters."); continue
        pairs=sorted(zip(sents,cs),key=lambda x:x[1],reverse=True)
        cl,cr=st.columns(2)
        for col,pairs_slice,cls_name,pill_cls in [
            (cl,pairs[:n],"sent-pos","score-pill-pos"),
            (cr,pairs[-n:][::-1],"sent-neg","score-pill-neg"),
        ]:
            lbl2="Most Positive" if "pos" in cls_name else "Most Negative"
            col.markdown(f'<p style="font-size:.72rem;font-weight:700;'
                         f'text-transform:uppercase;letter-spacing:.06em;'
                         f'color:#737373;margin-bottom:.4rem">{lbl2}</p>',
                         unsafe_allow_html=True)
            for s,sc in pairs_slice:
                txt=s.replace("\n"," ").strip()
                if len(txt)>280: txt=txt[:280]+"…"
                col.markdown(
                    f'<div class="sent-card {cls_name}">'
                    f'<span class="score-pill {pill_cls}">{sc:+.4f}</span>{txt}'
                    f'</div>', unsafe_allow_html=True)
        st.write("")

# ═══════════════════════════════════════════════
# SIDEBAR
# ═══════════════════════════════════════════════
def sidebar():
    with st.sidebar:
        # Brand
        st.markdown(f"""
        <div style="padding:.8rem 0 .9rem;border-bottom:1px solid #333;margin-bottom:.7rem">
          <div style="display:flex;align-items:center;gap:.65rem">
            <div style="width:32px;height:32px;border-radius:8px;
                        background:linear-gradient(135deg,{GOLD},{GOLD_L});
                        display:flex;align-items:center;justify-content:center;
                        font-size:.85rem;font-weight:900;color:#1A1A1A">🏛</div>
            <div>
              <div style="font-size:.85rem;font-weight:800;color:{GOLD}">Budget NLP</div>
              <div style="font-size:.62rem;color:rgba(255,255,255,.4)">Command Center</div>
            </div>
          </div>
        </div>""", unsafe_allow_html=True)

        st.markdown('<p style="font-size:.62rem;font-weight:700;color:rgba(255,255,255,.3);'
                    'text-transform:uppercase;letter-spacing:.1em;margin-bottom:.4rem">Data Source</p>',
                    unsafe_allow_html=True)
        uploaded = st.file_uploader("Upload .txt files", type=["txt"], accept_multiple_files=True)
        demo     = st.button("📊 Load 3 Budget Speeches", use_container_width=True)
        run      = st.button("🚀 Run Analysis", use_container_width=True, type="primary",
                             disabled=(not uploaded and not demo
                                       and "texts" not in st.session_state))
        st.markdown("---")

        sel_docs=[]
        if "results" in st.session_state and st.session_state["results"]:
            all_l=st.session_state["results"]["labels"]
            st.markdown('<p style="font-size:.62rem;font-weight:700;color:rgba(255,255,255,.3);'
                        'text-transform:uppercase;letter-spacing:.1em;margin-bottom:.3rem">Documents</p>',
                        unsafe_allow_html=True)
            sel_docs=st.multiselect("Show",all_l,default=all_l,key="doc_f",
                                    label_visibility="collapsed")
            if not sel_docs: sel_docs=all_l
            st.markdown("---")

        st.markdown('<p style="font-size:.62rem;font-weight:700;color:rgba(255,255,255,.3);'
                    'text-transform:uppercase;letter-spacing:.1em;margin-bottom:.3rem">Filters</p>',
                    unsafe_allow_html=True)
        sr  = st.slider("Sentiment range",-1.0,1.0,(-1.0,1.0),.05,key="sr")
        mw  = st.slider("Min words / sentence",3,30,5,key="mw")
        st.markdown("---")

        st.markdown('<p style="font-size:.62rem;font-weight:700;color:rgba(255,255,255,.3);'
                    'text-transform:uppercase;letter-spacing:.1em;margin-bottom:.3rem">Theme Filter</p>',
                    unsafe_allow_html=True)
        sel_themes=st.multiselect("Themes",list(THEMES.keys()),
                                  default=list(THEMES.keys()),key="th_f",
                                  label_visibility="collapsed")
        if not sel_themes: sel_themes=list(THEMES.keys())
        st.markdown("---")

        st.markdown('<p style="font-size:.62rem;font-weight:700;color:rgba(255,255,255,.3);'
                    'text-transform:uppercase;letter-spacing:.1em;margin-bottom:.3rem">Model</p>',
                    unsafe_allow_html=True)
        n_topics   = st.slider("LDA topics",4,12,8,key="nt")
        top_n_glob = st.slider("TF-IDF top-N",10,25,20,key="tng")
        st.markdown("---")

        # Footer
        st.markdown(f"""
        <div style="display:flex;align-items:center;gap:.6rem;padding:.2rem 0">
          <div style="width:28px;height:28px;border-radius:50%;
                      background:rgba(218,165,32,.15);
                      display:flex;align-items:center;justify-content:center;font-size:.7rem">🛡️</div>
          <div>
            <div style="font-size:.72rem;font-weight:600;color:#FFFFFF">Budget Analysis</div>
            <div style="font-size:.6rem;color:rgba(255,255,255,.3)">NLP Intelligence · 2026</div>
          </div>
        </div>""", unsafe_allow_html=True)

    return uploaded, demo, run, sel_docs, sr, mw, sel_themes, n_topics, top_n_glob

# ═══════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════
def main():
    (uploaded, demo, run,
     sel_docs, sr, mw,
     sel_themes, n_topics, top_n_glob) = sidebar()

    if demo:
        texts={}
        for lbl,path in DEMO_FILES.items():
            try:
                with open(path,encoding="utf-8",errors="replace") as f:
                    texts[lbl]=f.read()
            except FileNotFoundError:
                st.sidebar.error(f"File not found: {path}")
        if texts:
            st.session_state["texts"]=texts
            st.session_state["results"]=None

    if uploaded:
        st.sidebar.subheader("Labels")
        li={}
        for f in uploaded:
            li[f.name]=st.sidebar.text_input(
                f"Label for '{f.name}'",value=os.path.splitext(f.name)[0],key=f"lbl_{f.name}")
        texts={li[f.name]:f.read().decode("utf-8","replace") for f in uploaded}
        st.session_state["texts"]=texts
        st.session_state["results"]=None

    if demo and "texts" in st.session_state:
        st.session_state["results"]=analyse(st.session_state["texts"])
    if run and "texts" in st.session_state:
        st.session_state["results"]=analyse(st.session_state["texts"])

    # Header bar
    is_live = "results" in st.session_state and st.session_state["results"] is not None
    if is_live:
        r=st.session_state["results"]
        n_docs=len(r["labels"])
        n_sents=sum(r["per_doc"][l]["stats"]["sentences"] for l in r["labels"])
        avg_c=sum(r["per_doc"][l]["mean_compound"] for l in r["labels"])/n_docs
    else:
        n_docs=n_sents=0; avg_c=None
    st.markdown(header_bar(is_live,n_docs,n_sents,avg_c), unsafe_allow_html=True)

    # Empty state
    if not is_live:
        st.markdown("""
        <div class="upload-hint">
          <h3>👆 Load documents to begin</h3>
          <p>Upload plain-text <code>.txt</code> files or click
             <strong>Load 3 Budget Speeches</strong> in the sidebar to get started.</p>
        </div>""", unsafe_allow_html=True)
        st.write("")
        feats=[
            ("🏠","Dashboard","KPI cards, trend lines, highlights"),
            ("☁️","Word Clouds","Token frequency colormaps"),
            ("📊","Sentiment","VADER + TextBlob deep analysis"),
            ("📉","Sentiment Graphs","Violin, heatmap, trajectory"),
            ("📈","Timeline","Rolling-average sentiment flow"),
            ("🔤","N-grams","Unigram / bigram / trigram"),
            ("🎯","Themes","10-theme heatmap + radar"),
            ("🔑","TF-IDF","Distinctive terms per document"),
            ("🗂️","Topics","LDA topic modeling"),
        ]
        c1,c2,c3=st.columns(3)
        for idx,(ico,ttl,desc) in enumerate(feats):
            [c1,c2,c3][idx%3].markdown(
                f'<div class="feat-card"><div class="feat-ico">{ico}</div>'
                f'<div class="feat-title">{ttl}</div>'
                f'<div class="feat-desc">{desc}</div></div>',
                unsafe_allow_html=True)
        return

    res       = st.session_state["results"]
    all_labels= res["labels"]
    labels    = [l for l in all_labels if l in sel_docs] if sel_docs else all_labels
    if not labels:
        st.warning("No documents selected. Adjust the Documents filter in the sidebar.")
        return

    # Active filter chips
    chips=[]
    if tuple(sr)!=(-1.0,1.0): chips.append(f"Sentiment {sr[0]:+.2f} → {sr[1]:+.2f}")
    if mw!=5: chips.append(f"Min words: {mw}")
    if len(sel_themes)!=len(THEMES): chips.append(f"Themes: {len(sel_themes)}/{len(THEMES)}")
    if len(labels)!=len(all_labels): chips.append(f"Docs: {len(labels)}/{len(all_labels)}")
    if chips:
        st.markdown('<div class="chips">'
                    +"".join(f'<span class="chip">🔹 {c}</span>' for c in chips)
                    +'</div>', unsafe_allow_html=True)

    t1,t2,t3,t4,t5,t6,t7,t8,t9,t10 = st.tabs([
        "🏠 Dashboard","☁️ Word Clouds","📊 Sentiment","📉 Sentiment Graphs",
        "📈 Timeline","🔤 N-grams","🎯 Themes","🔑 TF-IDF","🗂️ Topics","💬 Key Sentences",
    ])
    with t1:  tab_dashboard(res,labels,sr,mw)
    with t2:  tab_wordclouds(res,labels)
    with t3:  tab_vader(res,labels,sr,mw)
    with t4:  tab_sentiment_graphs(res,labels,sr,mw)
    with t5:  tab_timeline(res,labels)
    with t6:  tab_ngrams(res,labels)
    with t7:  tab_themes(res,labels,sel_themes)
    with t8:  tab_tfidf(res,labels,top_n_glob)
    with t9:  tab_topics(res,labels,n_topics)
    with t10: tab_key_sentences(res,labels,sr,mw)

if __name__=="__main__":
    main()
