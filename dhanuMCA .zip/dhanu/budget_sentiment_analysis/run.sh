#!/usr/bin/env bash
set -e

echo "======================================"
echo "  Budget Sentiment Analysis — Setup"
echo "======================================"

# 1. Python check
if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 not found. Please install Python 3.9+."
    exit 1
fi
echo "Python: $(python3 --version)"

# 2. Install pip dependencies
echo ""
echo "Installing Python dependencies..."
pip3 install -r requirements.txt --quiet

# 3. Download NLTK data
echo ""
echo "Downloading NLTK data packages..."
python3 - <<'EOF'
import nltk, sys
packages = [
    "punkt",
    "punkt_tab",
    "stopwords",
    "vader_lexicon",
    "wordnet",
    "omw-1.4",
    "averaged_perceptron_tagger",
]
for pkg in packages:
    try:
        nltk.download(pkg, quiet=True)
        print(f"  ✓ {pkg}")
    except Exception as e:
        print(f"  ! {pkg}: {e}", file=sys.stderr)
EOF

# 4. Run the app
echo ""
echo "======================================"
echo "  Launching Streamlit dashboard..."
echo "======================================"
echo "  Open http://localhost:8501 in your browser"
echo "  Press Ctrl+C to stop"
echo ""
streamlit run app.py
